-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1:3306
-- Время создания: Янв 11 2021 г., 15:18
-- Версия сервера: 8.0.19
-- Версия PHP: 7.4.5

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `australia4`
--

-- --------------------------------------------------------

--
-- Структура таблицы `doctrine_migration_versions`
--

CREATE TABLE `doctrine_migration_versions` (
  `version` varchar(191) COLLATE utf8_unicode_ci NOT NULL,
  `executed_at` datetime DEFAULT NULL,
  `execution_time` int DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `doctrine_migration_versions`
--

INSERT INTO `doctrine_migration_versions` (`version`, `executed_at`, `execution_time`) VALUES
('DoctrineMigrations\\Version20201213123611', '2020-12-13 15:36:33', 369),
('DoctrineMigrations\\Version20201227134750', '2020-12-27 16:48:04', 988);

-- --------------------------------------------------------

--
-- Структура таблицы `pages`
--

CREATE TABLE `pages` (
  `id` int NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `body` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `metatitle` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `keywords` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `pages`
--

INSERT INTO `pages` (`id`, `title`, `body`, `slug`, `metatitle`, `keywords`, `description`) VALUES
(1, 'Homepage', '<div class=\"decor reason__header\">\r\n<div class=\"reason__title title-2\">Not sure if you need this?</div>\r\n\r\n<div class=\"reason__subtitle text-desc\">Everyone who is looking for communication, friendship, feelings meets here</div>\r\n</div>\r\n\r\n<div class=\"reason__block\">\r\n<div class=\"reason-card\">\r\n<div class=\"col reason-card__img\"><img alt=\"img1\" src=\"/uploads/userfiles/img1.jpg\" /></div>\r\n\r\n<div class=\"col reason-card__text\">\r\n<div class=\"reason-card__title title-3\">What is dateassured.com?</div>\r\n\r\n<div class=\"reason-card__desc text\">\r\n<p>Unlike online dating websites and apps dateassured.com guarantees You will have a video conversation with a real <a href=\"/pages/test-page\" target=\"_blank\"><span style=\"color:#2980b9\">local person</span></a> tonight or on any other day.</p>\r\n\r\n<p>Unlike online dating websites and apps dateassured.com guarantees You will have a video conversation with a real local person tonight or on any other day.</p>\r\n</div>\r\n</div>\r\n</div>\r\n\r\n<div class=\"reason-card\">\r\n<div class=\"col reason-card__img\"><img alt=\"img2\" src=\"/uploads/userfiles/img2.jpg\" /></div>\r\n\r\n<div class=\"col reason-card__text\">\r\n<div class=\"reason-card__title title-3\">Advantages of dateasured.com?</div>\r\n\r\n<div class=\"reason-card__desc text\">\r\n<ul>\r\n	<li>All members are local;</li>\r\n	<li>No fake accounts - only real people;</li>\r\n	<li>Safe and secure environment;</li>\r\n	<li>Speed dating from a comfort of your home;</li>\r\n	<li>Video chat with as many people as you want;</li>\r\n	<li>No waiting lists, no frustrating nights</li>\r\n</ul>\r\n</div>\r\n</div>\r\n</div>\r\n\r\n<div class=\"reason-card\">\r\n<div class=\"col reason-card__img\"><img alt=\"img3\" src=\"/uploads/userfiles/img3.jpg\" /></div>\r\n\r\n<div class=\"col reason-card__text\">\r\n<div class=\"reason-card__title title-3\">Why join dateassured.com?</div>\r\n\r\n<div class=\"reason-card__desc text\">\r\n<ul>\r\n	<li>Realistic membership costs, no hidden fees or charges;</li>\r\n	<li>Same day online sessions or book your preferred date and time;</li>\r\n	<li>Guaranteed online video conversations with real people on any day of the week;</li>\r\n	<li>Choose who you like most and continue your acquaintanceship on a real date;</li>\r\n	<li>Convenience of both, app on your mobile device or a web version on your laptop / pc;</li>\r\n	<li>Secure online environment and 24hr online support</li>\r\n</ul>\r\n</div>\r\n</div>\r\n</div>\r\n</div>', 'home', 'gfgdfgfg', 'gdgdsg', 'gsdgdsgsdg'),
(2, 'Homepage Videoblock', '<div class=\"video__block\">\r\n            <iframe src=\"https://player.vimeo.com/video/147339136\" width=\"800\" height=\"440\" frameborder=\"0\"\r\n                    allow=\"autoplay; fullscreen\" allowfullscreen=\"\"></iframe>\r\n        </div>', 'video', '', '', ''),
(3, 'Testing an additional page', '<p><img alt=\"\" src=\"/uploads/userfiles/G01.jpg\" style=\"height:619px; width:1110px\" /></p>\r\n\r\n<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>\r\n\r\n<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>\r\n\r\n<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>\r\n\r\n<p>&nbsp;</p>', 'test-page', '', '', '');

-- --------------------------------------------------------

--
-- Структура таблицы `profile`
--

CREATE TABLE `profile` (
  `id` int NOT NULL,
  `username` varchar(180) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(180) COLLATE utf8mb4_unicode_ci NOT NULL,
  `country` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `city` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `gender` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `age` int NOT NULL,
  `height` int NOT NULL,
  `bodytype` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ethnicity` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `employment` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sexuality` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `prefer` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `purpose` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `balance` decimal(7,2) NOT NULL,
  `status` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `vip` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image_size` int NOT NULL,
  `updated_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `profile`
--

INSERT INTO `profile` (`id`, `username`, `email`, `country`, `city`, `gender`, `age`, `height`, `bodytype`, `ethnicity`, `phone`, `employment`, `sexuality`, `prefer`, `purpose`, `balance`, `status`, `vip`, `image_name`, `image_size`, `updated_at`) VALUES
(1, 'Admin', 'admin@admin.com', 'AL', 'Odessa', 'MALE', 18, 155, 'SLIM', 'ethnicity 1', '54435', 'INDUSTRY', 'STRAIGHT', 'OLDER', 'Ongoing relationship', '0.00', 'active', 'free', 'goauld168.jpg', 4397, '2020-12-27 17:12:03'),
(2, 'User01', 'user01@test.tt', 'AS', 'Papua', 'MALE', 18, 155, 'SLIM', 'ethnicity 2', '45345345', 'UNEMPLOYED', 'STRAIGHT', 'YOUNGER', 'Ongoing relationship', '0.00', 'active', 'free', 'barmaley1.jpg', 28845, '2020-12-28 14:41:27');

-- --------------------------------------------------------

--
-- Структура таблицы `user`
--

CREATE TABLE `user` (
  `id` int NOT NULL,
  `email` varchar(180) COLLATE utf8mb4_unicode_ci NOT NULL,
  `roles` json NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `user`
--

INSERT INTO `user` (`id`, `email`, `roles`, `password`, `created_at`) VALUES
(1, 'admin@admin.com', '[\"ROLE_ADMIN\"]', '$argon2id$v=19$m=65536,t=4,p=1$+NzVCMrrpaRmEDU56TMEiQ$HBLyvNwnVeVqcomu2yhLYI2rbwaO3GVyut1UV+aJ3mA', '2020-12-01 15:49:02'),
(2, 'user01@test.tt', '[\"ROLE_USER\"]', '$argon2id$v=19$m=65536,t=4,p=1$JCouunYAYigw//G0RiH4/g$ru/eLC173hJRQxc/zz7T/EFV6mUsN2kztCUylAW7CM0', '2020-12-27 17:38:00');

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `doctrine_migration_versions`
--
ALTER TABLE `doctrine_migration_versions`
  ADD PRIMARY KEY (`version`);

--
-- Индексы таблицы `pages`
--
ALTER TABLE `pages`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `profile`
--
ALTER TABLE `profile`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `UNIQ_8157AA0FE7927C74` (`email`);

--
-- Индексы таблицы `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `UNIQ_8D93D649E7927C74` (`email`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `pages`
--
ALTER TABLE `pages`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT для таблицы `profile`
--
ALTER TABLE `profile`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT для таблицы `user`
--
ALTER TABLE `user`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
