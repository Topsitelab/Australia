-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1:3306
-- Время создания: Дек 21 2020 г., 15:02
-- Версия сервера: 8.0.19
-- Версия PHP: 7.4.5

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `australia4`
--

-- --------------------------------------------------------

--
-- Структура таблицы `doctrine_migration_versions`
--

CREATE TABLE `doctrine_migration_versions` (
  `version` varchar(191) COLLATE utf8_unicode_ci NOT NULL,
  `executed_at` datetime DEFAULT NULL,
  `execution_time` int DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `doctrine_migration_versions`
--

INSERT INTO `doctrine_migration_versions` (`version`, `executed_at`, `execution_time`) VALUES
('DoctrineMigrations\\Version20201213123611', '2020-12-13 15:36:33', 369),
('DoctrineMigrations\\Version20201214105522', '2020-12-14 14:00:06', 690),
('DoctrineMigrations\\Version20201214113956', '2020-12-14 14:40:11', 199),
('DoctrineMigrations\\Version20201216105946', '2020-12-16 14:00:09', 224);

-- --------------------------------------------------------

--
-- Структура таблицы `pages`
--

CREATE TABLE `pages` (
  `id` int NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `body` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `metatitle` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `keywords` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `user`
--

CREATE TABLE `user` (
  `id` int NOT NULL,
  `email` varchar(180) COLLATE utf8mb4_unicode_ci NOT NULL,
  `roles` json NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` datetime NOT NULL,
  `account` varchar(180) COLLATE utf8mb4_unicode_ci NOT NULL,
  `country` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `city` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `gender` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `age` int NOT NULL,
  `height` int NOT NULL,
  `bodytype` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ethnicity` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `employment` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sexuality` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `prefer` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `purpose` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `balance` decimal(7,2) NOT NULL,
  `status` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `vip` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `user`
--

INSERT INTO `user` (`id`, `email`, `roles`, `password`, `created_at`, `account`, `country`, `city`, `gender`, `age`, `height`, `bodytype`, `ethnicity`, `phone`, `employment`, `sexuality`, `prefer`, `purpose`, `balance`, `status`, `vip`) VALUES
(1, 'admin@admin.com', '[\"ROLE_ADMIN\"]', '$argon2id$v=19$m=65536,t=4,p=1$PLAcaZ32VbdRhsIrHIqD9Q$Rr9AR/aRxVM8u5RpPX0vYfz7fTNt4YlCACxbHTasCNA', '2020-12-13 13:00:31', 'Admin', '', '', '', 0, 0, '', '', '', '', '', '', '', '0.00', '', ''),
(2, 'user01@test.tt', '[\"ROLE_USER\"]', '$argon2id$v=19$m=65536,t=4,p=1$AlRZclctHiRgWla7F7wQPQ$B4cHkffWE0nM67iIIcR+UPJ2DNVd0xGboOnLjd19Vlk', '2020-12-14 14:15:16', 'Connor McLeod', 'AU', 'Sydney', 'MALE', 28, 189, 'ATHLETIC', 'ethnicity 1', '+38 (000) 000-00-00', 'INDUSTRY', 'STRAIGHT', 'OLDER, SAME AGE', 'Friendship, entirely platonic', '0.00', '', ''),
(3, 'user02@test.tt', '[\"ROLE_ADMIN\"]', '$argon2id$v=19$m=65536,t=4,p=1$AlRZclctHiRgWla7F7wQPQ$B4cHkffWE0nM67iIIcR+UPJ2DNVd0xGboOnLjd19Vlk', '2020-12-14 14:43:29', 'User02', '', '', '', 0, 0, '', '', '', '', '', '', '', '0.00', '', ''),
(4, 'user03@test.tt', '[\"ROLE_USER\"]', '$argon2id$v=19$m=65536,t=4,p=1$YMtYEALNRFckSqQsiFep2A$rmnzOeoGYAc9KGn0F6q8XfZJONhXRmnsX6Y+cDqt010', '2020-12-21 14:41:43', 'Don Pedro Lopes', '', '', '', 18, 155, '', '', '', '', '', '', '', '0.00', 'active', 'free'),
(5, 'user04@test.tt', '[\"ROLE_USER\"]', '$argon2id$v=19$m=65536,t=4,p=1$CqCatdHiIldRVXuX56g+/A$suHqOaaxkgyTtPwiUzs143/yGkNMM+JrAOoYfZ6Hc2M', '2020-12-21 14:45:51', 'Kalunda Kintosh', '', '', '', 18, 155, '', '', '', '', '', '', '', '0.00', 'active', 'free'),
(6, 'chun@test.tt', '[\"ROLE_USER\"]', '$argon2id$v=19$m=65536,t=4,p=1$1SNNoiVqM6A0Z+gEtCZazA$DGAmrTfuBOiBWZjyNHLqnz8LUE9Wqr7/vaKZCRo7OHo', '2020-12-21 14:52:59', 'Chun Bak Dong', 'VN', 'Dyng Dong', 'MALE', 21, 157, 'SLIM', 'ethnicity 2', '5749353', 'UNEMPLOYED', 'GAY-LESBIAN', 'YOUNGER', 'Casual fun, no strings attached', '0.00', 'active', 'free');

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `doctrine_migration_versions`
--
ALTER TABLE `doctrine_migration_versions`
  ADD PRIMARY KEY (`version`);

--
-- Индексы таблицы `pages`
--
ALTER TABLE `pages`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `UNIQ_8D93D649E7927C74` (`email`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `pages`
--
ALTER TABLE `pages`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `user`
--
ALTER TABLE `user`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
